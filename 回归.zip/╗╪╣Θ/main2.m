clc;
clear;

load("preprocessed_finger_1dof.mat")
load("force_finger_1dof.mat")
emg_data = preprocessed_finger_1dof2;
force_data = force_finger_1dof2;
clear preprocessed_finger_1dof2 force_finger_1dof2


Ntrial = size(emg_data,2);
t = 25;
fs = 2048;
Nsample = t * fs;
Nchannel = 256;
zc_ssc_thresh = 0.0004; 
window_length = 0.5;
step_length = 0.5;
feature = [];
window_sample = floor(window_length*fs); 
step_sample = floor(step_length*fs);

%��ȡ������������
for i = 1:Ntrial
    emg = emg_data{1,i};
    fea_idx = 0;
    for j = 1:step_sample:(Nsample-window_sample+1)
        fea_idx = fea_idx + 1;
        sig = emg(j:j+window_sample-1,:);
        sig = reshape(sig,[1,numel(sig)]);
        rms(fea_idx) = sqrt(mean(sig.^2));
        wl_value = 0;
            zc_value = 0;
            ssc_value = 0;
            N = length(sig);
            for k = 1:N-1
                wl_value = wl_value+abs(sig(k+1)-sig(k));
                if( (abs(sig(k+1)-sig(k))>zc_ssc_thresh) && (sig(k)*sig(k+1)<0) )
                    zc_value = zc_value + 1;
                end
            end
            for k = 2:N-1
                if( ((sig(k)-sig(k-1))*(sig(k)-sig(k+1))>0) && ( (abs(sig(k+1)-sig(k))>zc_ssc_thresh) || (abs(sig(k-1)-sig(k))>zc_ssc_thresh) ) )
                    ssc_value = ssc_value + 1;
                end
            end
            wl(fea_idx) = wl_value / N * fs;
            zc(fea_idx) = zc_value;
            ssc(fea_idx) = ssc_value;
    end
    feature = [rms' wl' zc' ssc'];
    feature = {feature};
    feature_norm(i) = feature;
end


clear emg_data emg rms sig ssc wl zc feature 

%��ȡ������������
fs_force = 100;
force_ground_truth = [];
for i = 1:length(force_data)
    force = force_data{1,i}(:,2);
    force = resample(force,2,fs_force);
    force_ground_truth = [force_ground_truth force];
end

clear force force_data


for i = 1:Ntrial
    feature = feature_norm;
    feature_train = [];
    force_train = [];
    feature_test = feature{1,i};
    feature(i) = [];
    force = force_ground_truth;
    force_test = force(:,i);
    force(:,i) = [];
    for j = 1:Ntrial-1
        feature_train = [feature_train;feature{1,j}];
        force_train = [force_train;force(:,j)];
    end
    feature_train(:,5) = 1;
    feature_test(:,5) = 1;

    X = feature_train;
    Y = force_train;
    X = X*diag(sparse(1./sqrt(sum(X.^2))));
    num_iters = 0;
    alpha = 1e-2;
    theta = [0.1;0.1;0.1;0.1;0.1];
    while true
        deta_theta = alpha*X'*(Y - X*theta);
        theta = theta + deta_theta;
        num_iters = num_iters + 1;
        if num_iters> 200000 || sum((X*theta-Y).^2)/50 < 0.0001
            break
        end
    end
    
    feature_test = feature_test*diag(sparse(1./sqrt(sum(feature_test.^2))));
    force_estimate = feature_test * theta;
    figure(i)
    plot(force_test,'r');
    hold on;
    plot(force_estimate,'b');

    RMSE = sum((force_estimate - force_test).^2)/50
end




 
