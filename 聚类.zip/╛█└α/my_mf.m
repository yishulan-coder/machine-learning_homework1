function mf_value=my_mf(sig)

mf_value = meanfreq(sig) ;




