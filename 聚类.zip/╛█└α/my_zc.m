function zc_value=my_zc(sig)

sigma = std(sig);
t = (sig>= 0.03*sigma);
zc_value = sum(t);



